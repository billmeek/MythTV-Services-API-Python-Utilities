"""
This is the one and only place that the
current version is stored.
"""
__version__ = '0.1.0'
