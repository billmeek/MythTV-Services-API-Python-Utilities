See the README.md under dist for installation options.

For complete help, try this:
```
$ python
>>> from mythtv_services_api import send as api, utilities as util
>>> help(api)
>>> help(util)
```


