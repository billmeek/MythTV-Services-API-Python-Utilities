"""Single place for the current version"""
__version__ = '0.0.5'
