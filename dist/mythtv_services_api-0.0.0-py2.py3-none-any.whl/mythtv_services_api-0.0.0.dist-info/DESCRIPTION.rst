For complete help, try this:
```
$ python
>>> from MythTVServicesAPI import send as api
>>> from MythTVServicesAPI import utilities as util
>>> help(api)
>>> help(util)
```


